import { Component, OnInit } from '@angular/core';
import { FormGroup , FormControl, Validators } from '@angular/forms';
import { UserDetails } from '../create-case-add.model';

@Component({
  selector: 'app-bootstrap-template',
  templateUrl: './bootstrap-template.component.html',
  styleUrls: ['./bootstrap-template.component.css']
})
export class BootstrapTemplateComponent implements OnInit {
  myRegistrationForm!:any;
  submitted = false;
  constructor() { }

  ngOnInit(): void {
    this.myRegistrationForm = new FormGroup({
      myCompanyCode: new FormControl('',Validators.required),
      myProductName: new FormControl('',Validators.required),
      myEnterFault: new FormControl('',Validators.required),
      myEnterContactEmail: new FormControl('', Validators.compose([
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])),
      myEnterContactNo: new FormControl('', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]),
      // password: new FormControl('')
      });
  }
  get f() { return this.myRegistrationForm.controls; }
  onSubmitUserDetails(userData:UserDetails){
    this.submitted = true;
    console.log(this.myRegistrationForm)
    if(!this.myRegistrationForm()) {
      return;
    }
  }
  

}
