import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-case-add',
  templateUrl: './create-case-add.component.html',
  styleUrls: ['./create-case-add.component.css']
})
export class CreateCaseAddComponent implements OnInit {

  constructor(private router:Router ) { }

  ngOnInit(): void {
  }

}
