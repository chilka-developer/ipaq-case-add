import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { CreateCaseAddComponent } from './create-case-add/create-case-add.component';
import { ViewCaseComponent } from './view-case/view-case.component';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { HttpClientModule} from '@angular/common/http';
import { BootstrapTemplateComponent } from './bootstrap-template/bootstrap-template.component';
import { FormsModule,  ReactiveFormsModule }   from '@angular/forms';


const appRoutes :Routes = [

  { path : 'create-case-add' , component : CreateCaseAddComponent},
  { path : 'bootstrap-template' , component : BootstrapTemplateComponent},
  { path : 'view-case' , component : ViewCaseComponent},
  { path : '' , redirectTo: '/bootstrap-template' , pathMatch: 'full' }
 
];

@NgModule({
  declarations: [
    AppComponent,
    CreateCaseAddComponent,
    ViewCaseComponent,
    FileUploadComponent,
    BootstrapTemplateComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
