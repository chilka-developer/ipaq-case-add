import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-case',
  templateUrl: './view-case.component.html',
  styleUrls: ['./view-case.component.css']
})
export class ViewCaseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
