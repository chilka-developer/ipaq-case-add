export class UserDetails{
    myCompanyCode : string;
    myProductName : string;
    myEnterFault : string;
    myEnterContactEmail : string;
    myEnterContactNo : number;
    
}